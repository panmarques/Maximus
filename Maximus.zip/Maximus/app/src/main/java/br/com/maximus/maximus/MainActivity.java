package br.com.maximus.maximus;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button botaoLogin = (Button)findViewById(R.id.botaoLoginMaximus);
        botaoLogin.setOnClickListener(this);
    }

    public void onClick(View v) {
        Toast.makeText(this,s, Toast.LENGTH_LONG).show();
    }
}
